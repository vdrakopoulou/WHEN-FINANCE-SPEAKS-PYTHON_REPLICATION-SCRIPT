"""
WHEN FINANCE SPEAKS PYTHON – REPLICATION SCRIPT
===============================================

This script reproduces all descriptive statistics, tables, figures,
and appendices from the scored curriculum dataset:

    Data/Python_in_Finance_Curriculum_scored.csv

Expected folder structure:

    replication_Q1/
        replication_analysis.py
        Data/
            Python_in_Finance_Curriculum_scored.csv
        Tables/
        Figures/
        Appendices/

Running this script will (re)write:

    - Tables 1–7 as CSV files in Tables/
    - Figures 2–3 as PNG files in Figures/
    - Appendices A1–A2, B1–B2, C1–C2, D1–D2 as CSV files in Appendices/

Usage (from inside replication_Q1/):

    python replication_analysis.py
"""

import os
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy import stats


# ---------------------------------------------------------------------
# 0. Paths and basic setup
# ---------------------------------------------------------------------

BASE = Path(__file__).resolve().parent
DATA_DIR = BASE / "Data"
TABLES_DIR = BASE / "Tables"
FIGS_DIR = BASE / "Figures"
APX_DIR = BASE / "Appendices"

for p in [DATA_DIR, TABLES_DIR, FIGS_DIR, APX_DIR]:
    p.mkdir(parents=True, exist_ok=True)

DATA_FILE = DATA_DIR / "Python_in_Finance_Curriculum_scored.csv"

if not DATA_FILE.exists():
    raise FileNotFoundError(f"Data file not found: {DATA_FILE}")


# ---------------------------------------------------------------------
# 1. Load data
# ---------------------------------------------------------------------

df = pd.read_csv(DATA_FILE)

required_cols = [
    "University_ID", "Country", "University_Name", "Program_Name",
    "Degree_Level", "Python_Found",
    "Depth", "Scope", "Authenticity",
    "Python_Index", "Python_Index_Normalised",
]
missing = [c for c in required_cols if c not in df.columns]
if missing:
    raise ValueError(f"Missing required columns in data file: {missing}")


# ---------------------------------------------------------------------
# 2. Helper functions
# ---------------------------------------------------------------------

def cronbach_alpha(items: pd.DataFrame) -> float:
    """Compute Cronbach's alpha for a set of item columns."""
    items = items.dropna()
    k = items.shape[1]
    if k <= 1:
        return np.nan
    item_var = items.var(axis=0, ddof=1)
    total_var = items.sum(axis=1).var(ddof=1)
    if total_var == 0:
        return np.nan
    return k / (k - 1) * (1 - item_var.sum() / total_var)


def one_factor_loadings(items: pd.DataFrame) -> pd.Series:
    """Compute 1-factor loadings from the correlation matrix."""
    items = items.dropna()
    corr = items.corr()
    eigvals, eigvecs = np.linalg.eig(corr.values)
    idx = np.argmax(eigvals)
    first_ev = eigvals[idx].real
    first_vec = eigvecs[:, idx].real
    loadings = first_vec * np.sqrt(first_ev)
    return pd.Series(loadings, index=corr.columns)


def coef_table(result: sm.regression.linear_model.RegressionResultsWrapper) -> pd.DataFrame:
    """Return regression coefficients, SE, z, p, and confidence intervals."""
    coefs = result.params
    se = result.bse
    z = coefs / se
    p = result.pvalues
    ci = result.conf_int()
    return pd.DataFrame({
        "B": coefs,
        "SE_B": se,
        "z": z,
        "p": p,
        "CI_low": ci[0],
        "CI_high": ci[1],
    })


# ---------------------------------------------------------------------
# 3. Derived variables and subsamples
# ---------------------------------------------------------------------

# Graduate vs undergraduate dummy
UNDERGRAD_LEVELS = {
    "bsc", "ba", "bba", "bsba", "bcom", "b.econ",
    "undergraduate discipline", "ma (hons)",
}

def classify_grad(level):
    if isinstance(level, str):
        lvl = level.lower()
        return 0 if lvl in UNDERGRAD_LEVELS else 1
    return np.nan

df["graduate_program"] = df["Degree_Level"].apply(classify_grad)

# Coded subsamples
coded_sample = df[df[["Depth", "Scope", "Authenticity"]].notna().all(axis=1)].copy()
index_sample = coded_sample[coded_sample["Python_Index_Normalised"].notna()].copy()

print(f"Total programmes in file: {len(df)}")
print(f"Programmes with full rubric (Depth/Scope/Authenticity): {len(coded_sample)}")
print(f"Programmes with non-missing Python_Index_Normalised: {len(index_sample)}")


# ---------------------------------------------------------------------
# 4. Main tables
# ---------------------------------------------------------------------

# ---------- Table 1: Normalised index by country + ANOVA ----------

table1 = (
    index_sample
    .groupby("Country")["Python_Index_Normalised"]
    .agg(["mean", "median", "count"])
    .rename(columns={"mean": "M", "count": "Programs_n"})
    .sort_values("M", ascending=False)
)
table1.to_csv(TABLES_DIR / "table1_normalised_index_by_country.csv")

groups = [
    g["Python_Index_Normalised"].dropna().values
    for _, g in index_sample.groupby("Country")
    if g["Python_Index_Normalised"].notna().any()
]

if len(groups) >= 2:
    f_stat, p_val = stats.f_oneway(*groups)
    overall_mean = index_sample["Python_Index_Normalised"].mean()
    ss_between = sum(len(g) * (g.mean() - overall_mean) ** 2 for g in groups)
    ss_total = ((index_sample["Python_Index_Normalised"] - overall_mean) ** 2).sum()
    eta_sq = ss_between / ss_total if ss_total > 0 else np.nan
else:
    f_stat = p_val = eta_sq = np.nan

with open(TABLES_DIR / "table1_anova.txt", "w", encoding="utf-8") as f:
    f.write("One-way ANOVA by country\n")
    f.write(f"F = {f_stat:.2f}, p = {p_val:.3g}, eta^2 = {eta_sq:.3f}\n")


# ---------- Table 2: Normalised index by degree level ----------

table2 = (
    index_sample
    .groupby("Degree_Level")["Python_Index_Normalised"]
    .agg(["mean", "median", "count"])
    .rename(columns={"mean": "M", "count": "Programs_n"})
    .sort_values("M", ascending=False)
)
table2.to_csv(TABLES_DIR / "table2_normalised_index_by_degree_level.csv")


# ---------- Table 3: Mean depth, scope, authenticity by country ----------

table3 = (
    coded_sample
    .groupby("Country")[["Depth", "Scope", "Authenticity"]]
    .mean()
    .rename(columns={
        "Depth": "Depth_M",
        "Scope": "Scope_M",
        "Authenticity": "Authenticity_M",
    })
)
table3["Programs_n"] = coded_sample.groupby("Country")["Program_Name"].count()
table3 = table3[["Programs_n", "Depth_M", "Scope_M", "Authenticity_M"]]
table3.to_csv(TABLES_DIR / "table3_depth_scope_authenticity_by_country.csv")


# ---------- Table 4: Reliability and factor structure ----------

items = coded_sample[["Depth", "Scope", "Authenticity"]]
alpha = cronbach_alpha(items)
loadings = one_factor_loadings(items)

table4 = pd.DataFrame({
    "Measure_Item": ["Scale total", "Depth", "Scope", "Authenticity"],
    "Cronbach_Alpha": [alpha, np.nan, np.nan, np.nan],
    "Factor1_Loading": [
        np.nan,
        loadings.get("Depth", np.nan),
        loadings.get("Scope", np.nan),
        loadings.get("Authenticity", np.nan),
    ],
})
table4.to_csv(TABLES_DIR / "table4_reliability_factor_structure.csv", index=False)


# ---------- Table 5: OLS regression (graduate vs undergraduate) ----------

reg_data = index_sample.dropna(subset=["graduate_program"]).copy()
reg_data["graduate_program"] = reg_data["graduate_program"].astype(int)

model_ols = smf.ols(
    "Python_Index_Normalised ~ graduate_program", data=reg_data
).fit(cov_type="HC3")

table5 = coef_table(model_ols)
table5.to_csv(TABLES_DIR / "table5_ols_regression.csv")

with open(TABLES_DIR / "table5_ols_summary.txt", "w", encoding="utf-8") as f:
    f.write(model_ols.summary().as_text())


# ---------- Table 6: Mixed-effects model (random intercept by country) ----------

mixed_data = reg_data.dropna(subset=["Country"]).copy()
mixed_data["graduate_program"] = mixed_data["graduate_program"].astype(float)

if mixed_data["Country"].nunique() >= 2:
    md = sm.MixedLM.from_formula(
        "Python_Index_Normalised ~ graduate_program",
        groups="Country",
        data=mixed_data,
    )
    mixed_res = md.fit(reml=False)

    params = mixed_res.params
    bse = mixed_res.bse

    table6 = pd.DataFrame({
        "Parameter": params.index,
        "Estimate": params.values,
        "SE": bse.values,
        "z": params.values / bse.values,
        "p": mixed_res.pvalues.values,
    })
    table6.to_csv(TABLES_DIR / "table6_mixed_model.csv", index=False)

    with open(TABLES_DIR / "table6_mixed_model_summary.txt", "w", encoding="utf-8") as f:
        f.write(mixed_res.summary().as_text())
else:
    table6 = pd.DataFrame(columns=["Parameter", "Estimate", "SE", "z", "p"])
    table6.to_csv(TABLES_DIR / "table6_mixed_model.csv", index=False)
    with open(TABLES_DIR / "table6_mixed_model_summary.txt", "w", encoding="utf-8") as f:
        f.write("Mixed-effects model not estimated: fewer than 2 countries in data.\n")


# ---------- Table 7: Robustness checks (A: all programmes, B: Python-present only) ----------

robust_all = df.copy()
robust_all["Python_Index_Normalised_full"] = robust_all["Python_Index_Normalised"].fillna(0)
robust_all = robust_all.dropna(subset=["graduate_program"])
robust_all["graduate_program"] = robust_all["graduate_program"].astype(int)

model_A = smf.ols(
    "Python_Index_Normalised_full ~ graduate_program", data=robust_all
).fit(cov_type="HC3")

robust_py = robust_all[robust_all["Python_Found"] == "Y"].copy()
model_B = smf.ols(
    "Python_Index_Normalised_full ~ graduate_program", data=robust_py
).fit(cov_type="HC3")


def extract_single(result, var="graduate_program"):
    b = result.params[var]
    se = result.bse[var]
    p = result.pvalues[var]
    r2 = result.rsquared
    n = int(result.nobs)
    return b, se, p, r2, n


bA, seA, pA, r2A, nA = extract_single(model_A)
bB, seB, pB, r2B, nB = extract_single(model_B)

table7 = pd.DataFrame({
    "Model": ["A: All programmes", "B: Python-present only"],
    "B_graduate_program": [bA, bB],
    "SE_B": [seA, seB],
    "p": [pA, pB],
    "R2": [r2A, r2B],
    "n": [nA, nB],
})
table7.to_csv(TABLES_DIR / "table7_robustness_checks.csv", index=False)


# ---------------------------------------------------------------------
# 5. Figures
# ---------------------------------------------------------------------

# Figure 2: Mean normalised index by country
fig2_data = table1.sort_values("M", ascending=False)

plt.figure(figsize=(10, 5))
plt.bar(fig2_data.index, fig2_data["M"])
plt.xticks(rotation=45, ha="right")
plt.ylabel("Mean normalised Python index")
plt.tight_layout()
plt.savefig(FIGS_DIR / "figure2_mean_index_by_country.png", dpi=300)
plt.close()

# Figure 3: Depth, scope, authenticity by country
fig3_data = table3[["Depth_M", "Scope_M", "Authenticity_M"]]
x = np.arange(len(fig3_data.index))
w = 0.25

plt.figure(figsize=(12, 5))
plt.bar(x - w, fig3_data["Depth_M"], width=w, label="Depth")
plt.bar(x, fig3_data["Scope_M"], width=w, label="Scope")
plt.bar(x + w, fig3_data["Authenticity_M"], width=w, label="Authenticity")
plt.xticks(x, fig3_data.index, rotation=45, ha="right")
plt.ylabel("Mean score (0–4)")
plt.legend()
plt.tight_layout()
plt.savefig(FIGS_DIR / "figure3_depth_scope_authenticity_by_country.png", dpi=300)
plt.close()


# ---------------------------------------------------------------------
# 6. Appendices
# ---------------------------------------------------------------------

# Appendix A1: sample by country
apx_A1 = (
    df.groupby("Country")
    .agg(
        Universities_n=("University_Name", "nunique"),
        Programs_n=("Program_Name", "count"),
    )
    .sort_values("Programs_n", ascending=False)
)
apx_A1.to_csv(APX_DIR / "appendix_A1_sample_by_country.csv")

# Appendix A2: sample by degree level
apx_A2 = (
    df.groupby("Degree_Level")["Program_Name"]
    .agg(["count"])
    .rename(columns={"count": "Programs_n"})
    .sort_values("Programs_n", ascending=False)
)
apx_A2.to_csv(APX_DIR / "appendix_A2_sample_by_degree_level.csv")

# Appendix B1: rubric definitions
b1_rows = [
    ("Depth", 0, "No documented Python in the formal finance curriculum."),
    ("Depth", 1, "Single elective, workshop or thesis-level use of Python."),
    ("Depth", 2, "One structured Python or Python-in-finance course; limited follow-on use."),
    ("Depth", 3, "Core Python/programming course plus multiple follow-on finance modules using Python."),
    ("Depth", 4, "Python embedded vertically across the programme, from entry/preparation through core and advanced finance courses."),
    ("Scope", 0, "No finance modules explicitly using Python."),
    ("Scope", 1, "Python used in one module or narrow set of activities."),
    ("Scope", 2, "Python concentrated in a FinTech/data-analytics cluster of modules."),
    ("Scope", 3, "Python used across multiple subfields (e.g., econometrics, risk, derivatives, trading)."),
    ("Scope", 4, "Python is the dominant implementation language across most finance teaching."),
    ("Authenticity", 0, "Only generic mention of software; no assessed Python work."),
    ("Authenticity", 1, "Toy examples or demonstrations; little assessed coding."),
    ("Authenticity", 2, "Assessed labs or exercises using Python with simplified datasets."),
    ("Authenticity", 3, "Graded projects and/or exams using Python with real financial data in course settings."),
    ("Authenticity", 4, "Extended, project-based or external-facing work (e.g., capstones, industry projects) built around Python."),
]
apx_B1 = pd.DataFrame(b1_rows, columns=["Dimension", "Score", "Description"])
apx_B1.to_csv(APX_DIR / "appendix_B1_rubric_definitions.csv", index=False)

# Appendix B2: rubric examples
example_rows = [
    ("Massachusetts Institute of Technology (MIT)", "Master of Finance (MFin)", "United States", 4, 3, 3),
    ("Bayes Business School", "MSc in Quantitative Finance", "United Kingdom", 4, 3, 3),
    ("Frankfurt School of Finance & Management", "Master of Finance (MSc)", "Germany", 4, 3, 3),
    ("University of Mannheim", "MSc Economics (Python in Finance elective)", "Germany", 1, 1, 3),
    ("Central University of Finance and Economics", "Fintech undergraduate major", "China", 2, 1, 2),
    ("Typical applied finance master (no explicit Python)", "—", "Generic country", 0, 0, 0),
]
apx_B2 = pd.DataFrame(
    example_rows,
    columns=["University", "Programme", "Country", "Depth", "Scope", "Authenticity"],
)
apx_B2.to_csv(APX_DIR / "appendix_B2_rubric_examples.csv", index=False)

# Appendix C1: descriptives for key variables
apx_C1 = (
    coded_sample[["Depth", "Scope", "Authenticity", "Python_Index", "Python_Index_Normalised"]]
    .describe()
    .T
)
apx_C1.to_csv(APX_DIR / "appendix_C1_descriptives_key_variables.csv")

# Appendix C2: correlation matrix
apx_C2 = coded_sample[
    ["Depth", "Scope", "Authenticity", "Python_Index", "Python_Index_Normalised"]
].corr()
apx_C2.to_csv(APX_DIR / "appendix_C2_correlation_matrix.csv")

# Appendix D1: full OLS regression table
apx_D1 = coef_table(model_ols)
apx_D1["R2"] = model_ols.rsquared
apx_D1["n"] = int(model_ols.nobs)
apx_D1.to_csv(APX_DIR / "appendix_D1_full_ols_regression.csv", index=False)

# Appendix D2: mixed-effects parameters (if model estimated)
if "mixed_res" in locals():
    fe = mixed_res.fe_params
    re_var = mixed_res.cov_re.iloc[0, 0]
    resid_var = mixed_res.scale
    apx_D2 = pd.DataFrame({
        "Parameter": list(fe.index) + ["Var(country intercept)", "Var(residual)"],
        "Estimate": list(fe.values) + [re_var, resid_var],
    })
else:
    apx_D2 = pd.DataFrame(columns=["Parameter", "Estimate"])
apx_D2.to_csv(APX_DIR / "appendix_D2_mixed_effects_parameters.csv", index=False)

print("\nReplication complete.")
print("Tables written to:   ", TABLES_DIR)
print("Figures written to:  ", FIGS_DIR)
print("Appendices written to:", APX_DIR)
