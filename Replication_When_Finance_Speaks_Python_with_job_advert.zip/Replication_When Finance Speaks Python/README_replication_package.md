# Replication Package: When Finance Speaks Python

This replication package contains the coded curriculum dataset, analysis scripts, tables, figures, appendices, and supplementary job-advert materials for the manuscript *Closing or Reproducing the Skills Gap? Python Integration in Finance Degrees and the University-Industry Interface*.

## Key additions in this version

This version includes the uploaded Excel table files requested for replication:

- `Tables/Excel/table5_job_advert_curriculum_alignment.xlsx`
- `Tables/Excel/job_advert_addon_summary_final.xlsx`
- `Data/JobAdvert/job_ads_coded_for_table5.csv`

## Main folders

- `Data/`: scored curriculum data and supplementary job-advert coded data.
- `Tables/`: manuscript and appendix tables, including the new Excel table workbooks under `Tables/Excel/`.
- `Figures/`: generated figures.
- `Appendices/`: appendix tables and supporting outputs.
- `Code/`: replication analysis script.
- `Documentation/`: package manifest and checksums.

## Notes for double-anonymized review

The package is intended for blinded review. Public repository links, archive DOI, and author-identifying metadata should be added only after review, according to journal instructions.

## Reproducibility note

The original curriculum replication files are preserved. The supplementary job-advert Excel/CSV files have been added so that the job-advert alignment table can be inspected alongside the curriculum outputs.
