# File Manifest and SHA-256 Checksums

Generated: 2026-05-06T13:11:38Z

| File | Size bytes | SHA-256 |
|---|---:|---|
| `Appendices/appendix_A1_sample_by_country.csv` | 321 | `ac7573cfcd29badd6d833d76bc95f7ec53f0fac8d8697553b92024f58b766c68` |
| `Appendices/appendix_A2_sample_by_degree_level.csv` | 289 | `e8d36358fb7fa6cfb13933f2c963c95e63e04c51de89a5750c34dacc53f02901` |
| `Appendices/appendix_B1_rubric_definitions.csv` | 1283 | `2184875439b6c1ebae7779683c3011a34ae411eacfb4ca426039094cab2f8476` |
| `Appendices/appendix_B2_rubric_examples.csv` | 535 | `7c88e1233efe92f94c01885c7ec84649981af4d96dd0861acc9f214ea42c35c4` |
| `Appendices/appendix_C1_descriptives_key_variables.csv` | 407 | `3e5f5e3206e38ebb4bc9133b9e92b8854a0d79b510cb37cf80660392f81ac8c0` |
| `Appendices/appendix_C2_correlation_matrix.csv` | 525 | `ccc418c5d8501db1fc8b29f9f9ea54b93718e4292fccd8a902090850c64efe36` |
| `Appendices/appendix_D1_full_ols_regression.csv` | 319 | `f87fb1c8aa25d067dc3d32c5958dc11cad57bd7a34a55acd98e1d6e1165f8292` |
| `Appendices/appendix_D2_mixed_effects_parameters.csv` | 164 | `79eb04874be3f093698cfbf61e1e78c18decf25d5b9babb02f86a27f5bf94488` |
| `Code/replication_analysis.py` | 15930 | `0a402a9b13a48e32a90090e582899fa4ae2419afa5111601a9cb7aaa73a961bb` |
| `Data/JobAdvert/job_ads_coded_for_table5.csv` | 118247 | `2d59f7b6d89c66d92c881fd28350b59413dea50937ea71cd59c0487cb58d9f1e` |
| `Data/Python_in_Finance_Curriculum_scored.csv` | 90069 | `f20c90ae131accffc1773df33b1cefcbec8533344eaaa622759a9ad97f370e1d` |
| `Data/Python_in_Finance_Curriculum_scored.xlsx` | 44008 | `63f40d211cf89e633a16c345f01ab50087ec26868961068df2309efcedb230ff` |
| `Figures/figure2_mean_index_by_country.png` | 195969 | `057a374c42c93656f5a195c8e0a8cf5ba6c9ed95e63c16447a055c46d472b8ce` |
| `Figures/figure3_depth_scope_authenticity_by_country.png` | 206668 | `5b6a9762e754498a0d374ce5144b9496f22f91052e123196aa7dd223e37c0768` |
| `README_replication_package.md` | 1457 | `f56c652385c9184b2dd455ab3f113cf74cd1481552f61442dbd3d403444ee67c` |
| `Tables/Excel/job_advert_addon_summary_final.xlsx` | 56465 | `40d7dc9b4d2a8d23b45ad43526ab5e1cafe2763f81d3a65a1bf9cca3e7d5de0a` |
| `Tables/Excel/table5_job_advert_curriculum_alignment.xlsx` | 60209 | `bfb9e4fda9f8e3b8a85910771373f691a236b7a418562c5315e390265831710a` |
| `Tables/table1_anova.txt` | 63 | `84357267c97e1ef536726db3f2782908186e2a0f568ec1cc27ece07c57255d39` |
| `Tables/table1_normalised_index_by_country.csv` | 714 | `4faecc72c70c3d2c0605994bd2b7a4c7129f8ecf20c986c36732964ba19457fe` |
| `Tables/table2_normalised_index_by_degree_level.csv` | 945 | `ed0bf0b41e88f6a19adf29fd1accb68fe1a87861c991a0dba4b47a719a3d3545` |
| `Tables/table3_depth_scope_authenticity_by_country.csv` | 514 | `bf894c9b9ead0e04673f1ff24931e814e718edb8e789d424300fb7bc678c2bda` |
| `Tables/table4_reliability_factor_structure.csv` | 160 | `e0c30395af72e42325587d528abf8df23c0b474a2e9afc8fa1695387afb2ca3c` |
| `Tables/table5_ols_regression.csv` | 294 | `e3a07c6e4884b1a5f638c58155ba9ed674f6edc0ad055fa8d46ad0052d203613` |
| `Tables/table5_ols_summary.txt` | 1886 | `d91a605ae6f79a48a385531329e2931154525b7365f92cc64a14b13d4f8d7a4d` |
| `Tables/table6_mixed_model.csv` | 298 | `7fc0f3c03a212fabda6e6d4b236aa975d1d68fee8a8452a262741b7257336286` |
| `Tables/table6_mixed_model_summary.txt` | 1046 | `ad6f289ccfff0e29becd787d87b0cbc673007e3b10c4b2155c790ddcf8a0a8a3` |
| `Tables/table7_robustness_checks.csv` | 250 | `2e87a9ed1bdf9c290190bf4f2b7ded03c876b374a728c4b321eb658365f3bffd` |
